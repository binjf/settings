#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * //TODO
 * @author Sky
 * @date ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}.
 */
public class ${NAME} {
}
